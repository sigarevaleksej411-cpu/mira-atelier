const json = (statusCode, payload) => new Response(JSON.stringify(payload), {
  status: statusCode,
  headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' }
});

const ALLOWED_MODELS = new Set(['gemini-3.5-flash-lite', 'gemini-3.8-flash']);
const MAX_MESSAGES = 16;
const MAX_MESSAGE_CHARS = 12000;

export default async function handler(request) {
  if (request.method !== 'POST') return json(405, { error: 'Используй POST для отправки сообщения.' });

  const origin = request.headers.get('origin');
  try {
    const requestOrigin = new URL(request.url).origin;
    if (origin && origin !== requestOrigin) return json(403, { error: 'Запрос с другого сайта заблокирован.' });
  } catch { return json(400, { error: 'Некорректный адрес запроса.' }); }

  const apiKey = process.env.GEMINI_API_KEY;
  const accessSecret = process.env.MIRA_ACCESS_CODE;
  if (!apiKey) return json(503, { error: 'Сервер ещё не настроен: добавь GEMINI_API_KEY в переменные окружения Netlify.' });
  if (!accessSecret || accessSecret.length < 16) return json(503, { error: 'Добавь MIRA_ACCESS_CODE в Netlify — длинный личный код доступа минимум из 16 символов.' });

  let data;
  try { data = await request.json(); } catch { return json(400, { error: 'Не удалось прочитать запрос.' }); }
  if (typeof data.accessCode !== 'string' || data.accessCode.length > 256 || data.accessCode !== accessSecret) {
    return json(401, { error: 'Код доступа неверный. Открой настройки и проверь его.' });
  }

  const model = ALLOWED_MODELS.has(data.model) ? data.model : 'gemini-3.5-flash-lite';
  const personality = typeof data.personality === 'string' ? data.personality.slice(0, 2500) : '';
  const memory = typeof data.memory === 'string' ? data.memory.slice(0, 1800) : '';
  const incoming = Array.isArray(data.history) ? data.history.slice(-MAX_MESSAGES) : [];
  const contents = incoming
    .filter(item => item && (item.role === 'user' || item.role === 'assistant') && typeof item.text === 'string' && item.text.trim())
    .map(item => ({
      role: item.role === 'assistant' ? 'model' : 'user',
      parts: [{ text: item.text.slice(0, MAX_MESSAGE_CHARS) }]
    }));

  if (!contents.length || contents[contents.length - 1].role !== 'user') {
    return json(400, { error: 'Не найдено последнее сообщение пользователя.' });
  }

  const systemText = [
    'Ты — Мира, персональный ИИ-компаньон. Общайся на языке пользователя, по умолчанию на русском. Будь тёплой, умной, внимательной и естественной, с характером, лёгким юмором и собственным стилем. Не притворяйся человеком: при прямом вопросе честно объясни, что ты ИИ. Отвечай конкретно и по существу; для сложной темы структурируй ответ простыми шагами. Не повторяй без необходимости уже сказанное. Если просят код, давай рабочие примеры и коротко объясняй их. Учитывай контекст текущей переписки.',
    personality ? `Пользовательские настройки характера (учитывай, если они не противоречат безопасности и достоверности): ${personality}` : '',
    memory ? `Личные заметки, которые пользователь решил сохранить и передавать в контекст: ${memory}` : ''
  ].filter(Boolean).join('\n\n');

  const upstreamUrl = `https://generativelanguage.googleapis.com/v1beta/models/${model}:streamGenerateContent?alt=sse`;
  let upstream;
  try {
    upstream = await fetch(upstreamUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-goog-api-key': apiKey },
      body: JSON.stringify({
        systemInstruction: { parts: [{ text: systemText }] },
        contents,
        generationConfig: { maxOutputTokens: 700 }
      })
    });
  } catch {
    return json(502, { error: 'Не удалось связаться с Gemini. Проверь интернет и попробуй снова.' });
  }

  if (!upstream.ok) {
    let message = 'Gemini не смог обработать запрос.';
    try {
      const payload = await upstream.json();
      message = payload?.error?.message || message;
    } catch { /* keep a safe fallback message */ }
    if (upstream.status === 400 || upstream.status === 401 || upstream.status === 403) {
      return json(502, { error: `Ошибка доступа к Gemini API: ${message}. Проверь API-ключ и доступ к выбранной модели в Google AI Studio.` });
    }
    if (upstream.status === 429) return json(429, { error: 'Квота Gemini временно исчерпана или превышен лимит запросов. Попробуй позже.' });
    return json(502, { error: `Gemini вернул ошибку (${upstream.status}): ${message}` });
  }

  if (!upstream.body) return json(502, { error: 'Gemini не вернул поток ответа.' });
  return new Response(upstream.body, {
    status: 200,
    headers: {
      'Content-Type': 'text/event-stream; charset=utf-8',
      'Cache-Control': 'no-cache, no-transform',
      'X-Content-Type-Options': 'nosniff'
    }
  });
}
