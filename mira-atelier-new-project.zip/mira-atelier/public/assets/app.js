(() => {
  'use strict';
  const $ = (id) => document.getElementById(id);
  const KEYS = { settings: 'miraAtelier.v1.settings', chats: 'miraAtelier.v1.chats', current: 'miraAtelier.v1.currentChat' };
  const DEFAULT_PERSONALITY = 'Ты Мира — внимательная, любопытная и творческая собеседница. Общайся дружелюбно, естественно и без излишней официальности. Можешь шутить, задавать уместные вопросы и объяснять сложное простыми словами. Не соглашайся автоматически — мягко поправляй ошибки. Обычно отвечай по существу; если тема сложная, раскладывай по шагам.';
  const defaultSettings = { accessCode: '', model: 'gemini-3.5-flash-lite', personality: DEFAULT_PERSONALITY, memoryNotes: '', saveHistory: true };
  let settings = { ...defaultSettings, ...(readStorage(KEYS.settings, {}) || {}) };
  let chats = settings.saveHistory ? (readStorage(KEYS.chats, []) || []) : [];
  if (!Array.isArray(chats)) chats = [];
  chats = chats.filter(chat => chat && typeof chat.id === 'string' && Array.isArray(chat.messages)).slice(0, 60);
  let activeId = settings.saveHistory ? (localStorage.getItem(KEYS.current) || '') : '';
  if (!chats.some(chat => chat.id === activeId)) activeId = chats[0]?.id || '';
  let isSending = false;
  let toastTimer = null;
  let abortController = null;

  function readStorage(key, fallback) {
    try { const raw = localStorage.getItem(key); return raw ? JSON.parse(raw) : fallback; }
    catch { return fallback; }
  }
  function persist() {
    try {
      localStorage.setItem(KEYS.settings, JSON.stringify(settings));
      if (settings.saveHistory) {
        localStorage.setItem(KEYS.chats, JSON.stringify(chats.slice(0, 60)));
        if (activeId) localStorage.setItem(KEYS.current, activeId); else localStorage.removeItem(KEYS.current);
      } else {
        localStorage.removeItem(KEYS.chats);
        localStorage.removeItem(KEYS.current);
      }
    } catch { showToast('Браузер не смог сохранить историю. Возможно, хранилище заполнено.'); }
  }
  function id() { return (window.crypto && crypto.randomUUID) ? crypto.randomUUID() : `m${Date.now().toString(36)}${Math.random().toString(36).slice(2, 9)}`; }
  function activeChat() { return chats.find(chat => chat.id === activeId) || null; }
  function showToast(text) {
    const el = $('toast'); el.textContent = text; el.classList.add('visible');
    clearTimeout(toastTimer); toastTimer = setTimeout(() => el.classList.remove('visible'), 3200);
  }
  function status(kind, text) {
    $('statusPip').className = `live-pip ${kind || ''}`.trim(); $('statusText').textContent = text;
  }
  function makeChat() {
    const chat = { id: id(), title: 'Новый разговор', updatedAt: Date.now(), messages: [] };
    chats.unshift(chat); activeId = chat.id; persist(); renderAll(); $('messageInput').focus();
  }
  function newChat() {
    if (isSending) { showToast('Дождись ответа перед созданием нового разговора.'); return; }
    const current = activeChat();
    if (current && current.messages.length === 0) { renderAll(); $('messageInput').focus(); return; }
    makeChat(); closeSidebar();
  }
  function selectChat(chatId) {
    if (isSending && chatId !== activeId) { showToast('Дождись ответа, прежде чем переключать диалог.'); return; }
    activeId = chatId; persist(); renderAll(); closeSidebar();
  }
  function deleteChat(chatId) {
    if (isSending && chatId === activeId) { showToast('Сначала дождись завершения ответа.'); return; }
    chats = chats.filter(chat => chat.id !== chatId);
    if (activeId === chatId) activeId = chats[0]?.id || '';
    persist(); renderAll(); showToast('Разговор удалён.');
  }
  function updateTitle(chat) {
    if (!chat) return;
    const firstUser = chat.messages.find(message => message.role === 'user');
    if (firstUser) chat.title = firstUser.text.replace(/\s+/g, ' ').trim().slice(0, 38) || 'Новый разговор';
    chat.updatedAt = Date.now();
    chats.sort((a, b) => b.updatedAt - a.updatedAt);
  }
  function renderChatList() {
    const list = $('chatList'); const query = $('searchChats').value.trim().toLowerCase(); list.replaceChildren();
    const filtered = [...chats].sort((a, b) => b.updatedAt - a.updatedAt).filter(chat => {
      if (!query) return true;
      return chat.title.toLowerCase().includes(query) || chat.messages.some(m => m.text.toLowerCase().includes(query));
    });
    $('chatCount').textContent = String(chats.length).padStart(2, '0');
    $('emptyHistory').classList.toggle('visible', filtered.length === 0);
    $('emptyHistory').textContent = query ? 'Ничего не найдено.' : 'Здесь появятся твои разговоры.';
    filtered.forEach(chat => {
      const row = document.createElement('div'); row.className = `history-item${chat.id === activeId ? ' active' : ''}`;
      const open = document.createElement('button'); open.className = 'history-open'; open.type = 'button'; open.title = chat.title;
      const dot = document.createElement('span'); dot.className = 'history-dot';
      const title = document.createElement('span'); title.className = 'history-title'; title.textContent = chat.title || 'Новый разговор';
      open.append(dot, title); open.addEventListener('click', () => selectChat(chat.id));
      const remove = document.createElement('button'); remove.className = 'delete-chat'; remove.type = 'button'; remove.textContent = '×'; remove.title = 'Удалить разговор'; remove.setAttribute('aria-label', `Удалить: ${chat.title}`); remove.addEventListener('click', e => { e.stopPropagation(); deleteChat(chat.id); });
      row.append(open, remove); list.append(row);
    });
  }
  function escapeHtml(text) {
    return String(text).replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char]);
  }
  function renderMarkdown(text) {
    let safe = escapeHtml(text || '');
    const blocks = [];
    safe = safe.replace(/```([a-zA-Z0-9_-]*)\s*\n([\s\S]*?)```/g, (_, lang, code) => {
      const idx = blocks.length; blocks.push(`<pre><code>${code.replace(/\n$/, '')}</code></pre>`); return `__MIRA_CODE_BLOCK_${idx}__`;
    });
    safe = safe.replace(/`([^`\n]+)`/g, '<code>$1</code>');
    safe = safe.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>').replace(/\*(.+?)\*/g, '<em>$1</em>');
    safe = safe.split('\n').map(line => line.trim() ? `<p>${line}</p>` : '').join('');
    blocks.forEach((block, index) => { safe = safe.replace(`<p>__MIRA_CODE_BLOCK_${index}__</p>`, block); });
    return safe || '<p></p>';
  }
  function buildMessage(message, index) {
    const row = document.createElement('article'); row.className = `message ${message.role}`; row.dataset.index = String(index);
    const avatar = document.createElement('div'); avatar.className = 'message-avatar'; avatar.textContent = message.role === 'user' ? 'Я' : 'm✳';
    const main = document.createElement('div'); main.className = 'message-main';
    const meta = document.createElement('div'); meta.className = 'message-top';
    const name = document.createElement('b'); name.textContent = message.role === 'user' ? 'Ты' : 'Мира';
    const time = document.createElement('span'); time.textContent = message.time ? new Date(message.time).toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' }) : '';
    meta.append(name, time);
    const body = document.createElement('div'); body.className = 'message-body'; body.innerHTML = renderMarkdown(message.text);
    main.append(meta, body);
    if (message.role === 'assistant' && message.text) {
      const tools = document.createElement('div'); tools.className = 'message-tools';
      const copy = document.createElement('button'); copy.type = 'button'; copy.className = 'tool-btn'; copy.textContent = 'Копировать';
      copy.addEventListener('click', async () => { try { await navigator.clipboard.writeText(message.text); showToast('Ответ скопирован.'); } catch { showToast('Копирование не поддерживается этим браузером.'); } });
      tools.append(copy); main.append(tools);
    }
    row.append(avatar, main); return { row, body };
  }
  function renderMessages() {
    const list = $('messages'); list.replaceChildren();
    const chat = activeChat();
    if (!chat || chat.messages.length === 0) {
      $('welcome').hidden = false; list.hidden = true;
      $('currentTitle').textContent = 'Новый разговор'; return;
    }
    $('welcome').hidden = true; list.hidden = false;
    $('currentTitle').textContent = chat.title || 'Разговор';
    chat.messages.forEach((message, index) => list.append(buildMessage(message, index).row));
    requestAnimationFrame(scrollToBottom);
  }
  function renderAll() { renderChatList(); renderMessages(); }
  function scrollToBottom() { const scroll = $('conversationScroll'); scroll.scrollTop = scroll.scrollHeight; }
  function openSettings() {
    $('accessCode').value = settings.accessCode || '';
    $('modelSelect').value = settings.model || defaultSettings.model;
    $('personality').value = settings.personality || DEFAULT_PERSONALITY;
    $('memoryNotes').value = settings.memoryNotes || '';
    $('saveHistory').checked = settings.saveHistory !== false;
    $('settingsBackdrop').classList.remove('hidden');
    setTimeout(() => $('accessCode').focus(), 80);
  }
  function closeSettings() { $('settingsBackdrop').classList.add('hidden'); }
  function saveSettings() {
    const previousSave = settings.saveHistory;
    settings = {
      accessCode: $('accessCode').value.trim(),
      model: ['gemini-3.5-flash-lite', 'gemini-3.8-flash'].includes($('modelSelect').value) ? $('modelSelect').value : defaultSettings.model,
      personality: $('personality').value.trim().slice(0, 2500) || DEFAULT_PERSONALITY,
      memoryNotes: $('memoryNotes').value.trim().slice(0, 1800),
      saveHistory: $('saveHistory').checked
    };
    if (previousSave && !settings.saveHistory) {
      localStorage.removeItem(KEYS.chats); localStorage.removeItem(KEYS.current);
      showToast('Сохранение отключено: история останется только до закрытия вкладки.');
    } else if (!previousSave && settings.saveHistory) {
      showToast('С этого момента новые изменения будут сохраняться в браузере.');
    } else showToast('Настройки сохранены.');
    persist(); closeSettings();
    status(settings.accessCode ? '' : 'error', settings.accessCode ? 'Готово к подключению' : 'Нужен код доступа');
  }
  function openSidebar() { $('sidebar').classList.add('open'); $('mobileScrim').classList.add('show'); }
  function closeSidebar() { $('sidebar').classList.remove('open'); $('mobileScrim').classList.remove('show'); }
  function setBusy(busy) {
    isSending = busy; $('sendButton').disabled = busy; $('messageInput').disabled = busy;
    $('sendButton').innerHTML = busy ? '<span>Думаю…</span><i>· · ·</i>' : '<span>Отправить</span><i>↗</i>';
    if (busy) status('busy', 'Мира думает');
    else status(settings.accessCode ? 'ready' : '', settings.accessCode ? 'Облако подключено' : 'Нужен код доступа');
  }
  function parseSSEData(line, onText) {
    if (!line.startsWith('data:')) return;
    const raw = line.slice(5).trim(); if (!raw || raw === '[DONE]') return;
    try {
      const packet = JSON.parse(raw);
      const parts = packet?.candidates?.[0]?.content?.parts || [];
      for (const part of parts) if (typeof part.text === 'string') onText(part.text);
    } catch { /* Ignore incomplete or non-JSON event lines. */ }
  }
  async function requestReply(chat) {
    const response = await fetch('/.netlify/functions/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        accessCode: settings.accessCode,
        model: settings.model,
        personality: settings.personality,
        memory: settings.memoryNotes,
        history: chat.messages.slice(-16).map(message => ({ role: message.role, text: message.text.slice(0, 12000) }))
      }),
      signal: abortController.signal
    });
    const contentType = response.headers.get('content-type') || '';
    if (!response.ok || !contentType.includes('text/event-stream')) {
      let data = {};
      try { data = await response.json(); } catch { /* deployment not configured */ }
      if (response.status === 404 || !contentType.includes('application/json')) {
        throw new Error('Серверная функция не найдена. Проект нужно опубликовать через GitHub → Netlify, а не только перетащить как статический ZIP. Подробности есть в README.');
      }
      throw new Error(data.error || `Ошибка сервера (${response.status}).`);
    }
    if (!response.body) throw new Error('Браузер не поддерживает потоковый ответ.');
    const assistant = { role: 'assistant', text: '', time: Date.now() };
    chat.messages.push(assistant); updateTitle(chat); persist(); renderMessages();
    const list = $('messages'); const { body } = buildMessage(assistant, chat.messages.length - 1);
    const lastMessage = list.lastElementChild;
    const targetBody = lastMessage?.querySelector('.message-body') || body;
    targetBody.innerHTML = '<div class="typing-indicator" aria-label="Мира думает"><i></i><i></i><i></i></div>';
    const reader = response.body.getReader(); const decoder = new TextDecoder(); let buffer = ''; let hasText = false;
    const addLine = line => parseSSEData(line, fragment => {
      if (!fragment) return;
      hasText = true; assistant.text += fragment;
      targetBody.innerHTML = renderMarkdown(assistant.text);
      scrollToBottom();
    });
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split(/\r?\n/); buffer = lines.pop() || '';
      for (const line of lines) addLine(line);
    }
    buffer += decoder.decode(); if (buffer.trim()) addLine(buffer);
    if (!hasText) assistant.text = 'Я получила пустой ответ. Попробуй задать вопрос ещё раз.';
    assistant.time = Date.now(); updateTitle(chat); persist(); renderAll();
  }
  async function sendMessage(text) {
    const clean = text.trim(); if (!clean || isSending) return;
    if (!settings.accessCode) {
      showToast('Сначала введи код доступа в настройках.'); openSettings(); return;
    }
    if (!activeChat()) {
      const chat = { id: id(), title: 'Новый разговор', updatedAt: Date.now(), messages: [] };
      chats.unshift(chat); activeId = chat.id;
    }
    const chat = activeChat();
    chat.messages.push({ role: 'user', text: clean.slice(0, 12000), time: Date.now() });
    updateTitle(chat); persist(); $('messageInput').value = ''; resizeInput(); renderAll(); setBusy(true);
    abortController = new AbortController();
    try {
      await requestReply(chat);
    } catch (error) {
      if (error.name !== 'AbortError') {
        const message = { role: 'assistant', text: `**Не удалось получить ответ.**\n\n${error.message || 'Проверь подключение и попробуй снова.'}`, time: Date.now() };
        chat.messages.push(message); updateTitle(chat); persist(); renderAll(); status('error', 'Проблема подключения');
      }
    } finally {
      abortController = null; setBusy(false); renderChatList(); $('messageInput').focus();
    }
  }
  function resizeInput() { const input = $('messageInput'); input.style.height = 'auto'; input.style.height = `${Math.min(input.scrollHeight, 150)}px`; }

  $('newChat').addEventListener('click', newChat);
  $('openSettings').addEventListener('click', openSettings);
  $('sideSettings').addEventListener('click', () => { closeSidebar(); openSettings(); });
  $('setupButton')?.addEventListener('click', openSettings);
  $('closeSettings').addEventListener('click', closeSettings);
  $('settingsBackdrop').addEventListener('click', event => { if (event.target === $('settingsBackdrop')) closeSettings(); });
  $('saveSettings').addEventListener('click', saveSettings);
  $('openSidebar').addEventListener('click', openSidebar);
  $('closeSidebar').addEventListener('click', closeSidebar);
  $('mobileScrim').addEventListener('click', closeSidebar);
  $('searchChats').addEventListener('input', renderChatList);
  $('clearAll').addEventListener('click', () => {
    if (!confirm('Удалить все сохранённые разговоры на этом устройстве?')) return;
    chats = []; activeId = ''; persist(); renderAll(); showToast('История очищена.');
  });
  $('chatForm').addEventListener('submit', event => { event.preventDefault(); sendMessage($('messageInput').value); });
  $('messageInput').addEventListener('input', resizeInput);
  $('messageInput').addEventListener('keydown', event => {
    if (event.key === 'Enter' && !event.shiftKey && !event.isComposing) { event.preventDefault(); $('chatForm').requestSubmit(); }
  });
  document.querySelectorAll('[data-prompt]').forEach(button => button.addEventListener('click', () => sendMessage(button.dataset.prompt || '')));
  document.addEventListener('keydown', event => {
    if (event.key === 'Escape') { closeSettings(); closeSidebar(); }
    if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'k') { event.preventDefault(); newChat(); }
    if (event.key === '/' && document.activeElement !== $('messageInput') && document.activeElement !== $('searchChats') && !$('settingsBackdrop').classList.contains('hidden')) return;
    if (event.key === '/' && document.activeElement !== $('messageInput') && document.activeElement !== $('searchChats') && $('settingsBackdrop').classList.contains('hidden')) { event.preventDefault(); $('searchChats').focus(); }
  });

  renderAll();
  status(settings.accessCode ? '' : 'error', settings.accessCode ? 'Готово к подключению' : 'Нужен код доступа');
  if ('serviceWorker' in navigator && (location.protocol === 'https:' || location.hostname === 'localhost')) {
    window.addEventListener('load', () => navigator.serviceWorker.register('/sw.js').catch(() => {}));
  }
})();
